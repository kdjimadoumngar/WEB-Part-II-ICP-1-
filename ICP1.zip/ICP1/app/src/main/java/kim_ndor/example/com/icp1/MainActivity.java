package kim_ndor.example.com.icp1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.ButtonBarLayout;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public EditText Name;

    public EditText Password;

    public Button Login;

    public TextView Info;

    public int counter = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       /* Name = (EditText)findViewById(R.id.edName);
        Password = (EditText)findViewById(R.id.edPassword);
        Login = (Button)findViewById(R.id.btnLogin);

        Login.setOnclickListener(new

        Info = (TextView)findViewById(R.id.viewInfo);*/
        final EditText Name = findViewById(R.id.edName);
        final EditText Password = findViewById(R.id.edPassword);
        Button Login = findViewById(R.id.btnLogin);
        Info.setText("Number of Attempts Remaining: 3");

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                validateFunc(Name.getText().toString(), Password.getText().toString());


            }
        });


        Info = (TextView)findViewById(R.id.viewInfo);

    }

    public void validateFunc(String userName, String  userPassword){
       /*EditText Name = findViewById(R.id.edName);
       EditText Password = findViewById(R.id.edPassword);
       Button Login = findViewById(R.id.btnLogin);

       Info.setText("Number of Attempts Remaining: 3");

       Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                validatefunc(Name.getText().toString(), Password.getText().toString());


            }
        });


        Info = (TextView)findViewById(R.id.viewInfo);*/


        if ((userName == "Kim-Ndor") && (userPassword == "KimCourage@1")){
            Intent intent = new Intent(MainActivity.this, activity_my_second.class);
            startActivity(intent);
        }else{
            counter --;
            Info.setText("Number of Attempts Remaining: " + String.valueOf(counter));

            if (counter == 0){
                Login.setEnabled(false);
            }
        }
    }
}

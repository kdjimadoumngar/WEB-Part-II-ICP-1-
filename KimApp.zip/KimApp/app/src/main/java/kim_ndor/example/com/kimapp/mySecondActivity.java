package kim_ndor.example.com.kimapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class mySecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_second);
    }
}
